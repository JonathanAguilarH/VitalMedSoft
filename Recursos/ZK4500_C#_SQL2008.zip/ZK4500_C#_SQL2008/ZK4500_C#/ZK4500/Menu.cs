﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ZK4500
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }
        readonly string Pescado = "><))))°> ... o0O ... <°((((><";
        private void loadImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegistrarHuella_BD frm = new RegistrarHuella_BD();
            frm.MdiParent = this;
            frm.Show();
        }

        private void saveImageToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            VerificarHuella1a1 frm = new VerificarHuella1a1();
            frm.MdiParent = this;
            frm.Show();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            VerificarHuella1aN frm = new VerificarHuella1aN();
            frm.MdiParent = this;
            frm.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            Label1.Refresh();
            Label1.Text = DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second;
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            ToolStripStatusLabel4.Text = Pescado;
        }
    }
}
