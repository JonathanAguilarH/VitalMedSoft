﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using Sample; // BitmapFormat.cs
using System.Runtime.InteropServices;
using AxZKFPEngXControl;
using ZKFPEngXControl;
//using libzkfpcsharp;

namespace ZK4500
{
    public partial class RegistrarHuella_BD : Form
    {
        private String Ruta = System.Configuration.ConfigurationManager.AppSettings.Get("CadenaConeccion");
        AccesoDatos.clsaccesodatos servidor = new AccesoDatos.clsaccesodatos();
        public string __mesajeerror = "";

        private AxZKFPEngX ZkFprint = new AxZKFPEngX();
        private bool Check;

        public int id_trabajador = -1;

        int rpta = -1;
        string mensaje = "";

        //Add an event handler on OnEnroll Event
       private ZKFPEngX x = new ZKFPEngX();


        public RegistrarHuella_BD()
        {
            InitializeComponent();
        }

        private void RegistrarHuella_BD_Load(object sender, EventArgs e)
        {
            Controls.Add(ZkFprint);
            InitialAxZkfp();

            ////InitialZkfp();

            //FormHandle = this.Handle;
            //this.btn_iniciar.Click += new System.EventHandler(this.btn_iniciar_Click); //Le asigno el handler
            //btn_iniciar_Click(null, null);    //llamo al click de boton INICIAR  
        }


        private void RegistrarHuella_BD_KeyDown_1(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Escape))
            {
                this.Close();
            }
        }

        
        private void InitialZkfp()
        {
            x.OnEnroll += X_OnEnroll;

            //if (x.InitEngine() == 0)
            //{
            //    x.FPEngineVersion = "9";
            //    x.EnrollCount = 3;
            //    deviceSerial.Text += " " + x.SensorSN + " Count: " + x.SensorCount.ToString()
            //    + " Index: " + x.SensorIndex.ToString();
            //    ShowHintInfo("Device successfully connected");
            //}

        }
      
        private void X_OnEnroll(bool ActionResult, object ATemplate)
        {
            if (ActionResult)
            {
                if (x.LastQuality >= 80) //to ensure the fingerprint quality
                {
                    string regTemplate = x.GetTemplateAsStringEx("9");
                    string template = x.EncodeTemplate1(regTemplate);
                    //txtTemplate2.Text = template;
                    //File.WriteAllText(Application.StartupPath + "\\fingerprint.txt", regTemplate);
                }
                else
                {
                    ShowHintInfo("Buena Calidad");
                }
            }
            else
            {
                ShowHintInfo("Mala Calidad");
            }
        }
        private void InitialAxZkfp()
        {
            try
            {

                ZkFprint.OnImageReceived += zkFprint_OnImageReceived;
                ZkFprint.OnFeatureInfo += zkFprint_OnFeatureInfo;
                //zkFprint.OnFingerTouching 
                //zkFprint.OnFingerLeaving
                ZkFprint.OnEnroll += zkFprint_OnEnroll;

                if (ZkFprint.InitEngine() == 0)
                {
                    ZkFprint.FPEngineVersion = "9";
                    ZkFprint.EnrollCount = 3;
                    deviceSerial.Text += " " + ZkFprint.SensorSN + " Count: " + ZkFprint.SensorCount.ToString()
                    + " Index: " + ZkFprint.SensorIndex.ToString();
                    ShowHintInfo("Device successfully connected");
                }

            }
            catch (Exception ex)
            {
                ShowHintInfo("Device init err, error: " + ex.Message);
            }
        }

     
     
      

        private void zkFprint_OnImageReceived(object sender, IZKFPEngXEvents_OnImageReceivedEvent e)
        {
            Graphics g = fpicture.CreateGraphics();
            Bitmap bmp = new Bitmap(fpicture.Width, fpicture.Height);
            g = Graphics.FromImage(bmp);
            int dc = g.GetHdc().ToInt32();
            ZkFprint.PrintImageAt(dc, 0, 0, bmp.Width, bmp.Height);
            g.Dispose();
            fpicture.Image = bmp;
        }
        private void zkFprint_OnFeatureInfo(object sender, IZKFPEngXEvents_OnFeatureInfoEvent e)
        {

            String strTemp = string.Empty;
            if (ZkFprint.EnrollIndex != 1)
            {
                if (ZkFprint.IsRegister)
                {
                    if (ZkFprint.EnrollIndex - 1 > 0)
                    {
                        int eindex = ZkFprint.EnrollIndex - 1;
                        strTemp = "Please scan again ..." + eindex + "..." + ZkFprint.LastQuality;
                    }
                }
            }
            ShowHintInfo(strTemp);
        }
        private void zkFprint_OnEnroll(object sender, IZKFPEngXEvents_OnEnrollEvent e)
        {
            if (e.actionResult)
            {

                string template = ZkFprint.EncodeTemplate1(e.aTemplate);
                txtTemplate.Text = template;
                ShowHintInfo("Registration successful. You can verify now" + "..." + ZkFprint.LastQuality);
                //btnRegister.Enabled = false;
                //btnVerify.Enabled = true;
            }
            else
            {
                ShowHintInfo("Error, please register again.");

            }
        }
        private void zkFprint_OnCapture(object sender, IZKFPEngXEvents_OnCaptureEvent e)
        {
            string template = ZkFprint.EncodeTemplate1(e.aTemplate);
            //txtTemplate2.Text = template;

            if (ZkFprint.VerFingerFromStr(ref template, txtTemplate.Text, false, ref Check))
            {
                ShowHintInfo("Verified");
            }
            else
                ShowHintInfo("Not Verified");

        }



        private void ShowHintInfo(String s)
        {
            prompt.Text = s;
        }


        private void btnRegister_Click(object sender, EventArgs e)
        {
            ZkFprint.CancelEnroll();
            ZkFprint.EnrollCount = 1;
            ZkFprint.BeginEnroll();
            ShowHintInfo("Please give fingerprint sample.");
            Mensaje.Text = "";
        }

        public string ImageToBase64(Image image,  System.Drawing.Imaging.ImageFormat format)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                // Convert Image to byte[]
                image.Save(ms, format);
                byte[] imageBytes = ms.ToArray();

                // Convert byte[] to Base64 String
                string base64String = Convert.ToBase64String(imageBytes);
                return base64String;
            }
        }
        

   

        private void btnClear_Click(object sender, EventArgs e)
        {
        fpicture.Image = null;
        }

     
        public static string EncodeTo64UTF8(string m_enc)
        {
            byte[] toEncodeAsBytes =
            System.Text.Encoding.UTF8.GetBytes(m_enc);
            string returnValue =
            System.Convert.ToBase64String(toEncodeAsBytes);
            return returnValue;
        }
      
        private void BtnAceptar_Click(object sender, EventArgs e)
        {
           Boolean ok;
           ok = Txt_Nombre.Text != "";
            if ((ok == false))
            {
                MessageBox.Show("Ingrese Codigo por favor.", "ZK4500", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Txt_Nombre.Focus();
                return;
            }

            ok = txtTemplate.Text != "";
            if ((ok == false))
            {
                MessageBox.Show("Vuelva a Generar Huella.", "ZK4500", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                btnRegister.Focus();
                return;
            }

            //Fotografia = GetFileName(textBox1.Text).Replace(".", DateTime.Now.Ticks.ToString() + ".");
            //System.IO.File.Copy(textBox1.Text, @RutaFotos + Fotografia);
            ////template.Quality.ToString()
            string input = txtTemplate.Text.Trim();
            byte[] array = Encoding.ASCII.GetBytes(input);

            // Stream usado como buffer
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            // Se guarda la imagen en el buffer
            fpicture.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            // Se extraen los bytes del buffer para asignarlos como valor para el 
            // parámetro.
            //cmd.Parameters["@image"].Value = ms.GetBuffer();

            string Calidad = Convert.ToString (ZkFprint.LastQuality);
            //string Calidad="0";

            AccesoDatos.clsaccesodatos servidor = new AccesoDatos.clsaccesodatos();
            servidor.cadenaconexion = Ruta;
            if (servidor.abrirconexiontrans() == true)
            {
                servidor.ejecutar("[dbo].[BD_Pje_pa_mantenimiento_TrabajadorHuella]",
                    false
                    , ref rpta
                    , ref mensaje
                    , id_trabajador
                    ,Txt_Nombre.Text.Trim()
                    , ms.GetBuffer() //IMAGEN
                   , Calidad
                   ,txtTemplate.Text.Trim() //TEMPLATE
                   ////, Convert.ToByte(txtTemplate2.Text.Trim()) // BASE64 --- ESTA DE FORMA MOMENTANEA
                   ////, blob_1// BASE64 --- ESTA DE FORMA MOMENTANEA
                    ,ms.GetBuffer() //IMAGEN
                   ,"N" ,0 ,"");
                if (rpta > 0)
                {
                    //servidor.cerrarconexiontrans();
                    servidor.cerrarconexiontrans();
                    //__mesajeerror = servidor.getMensageError();
                    __mesajeerror = mensaje;
                    Mensaje.Text = mensaje;
                    //Mensaje.Text = __mesajeerror;
                    txtTemplate.Text = "";
                    fpicture.Image = null;
                    Txt_Nombre.Text = "";
                    MessageBox.Show(__mesajeerror, "ZK4500", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Hide();
                    //__mensaje.Value = mensaje;
                    //__pagina.Value = "CargarExcelGridviewBD.aspx";
                }
                else
                {
                    servidor.cancelarconexiontrans();
                    Mensaje.Text = __mesajeerror;
                    //__mesajeerror = servidor.getMensageError();
                    MessageBox.Show(__mesajeerror, "ZK4500", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    //servidor.cancelarconexiontrans();
                    //__mensaje.Value = mensaje;
                    //__pagina.Value = "CargarExcelGridviewBD.aspx";
                }

                //if (servidor.getRespuesta() == 1)
                //{
                //    servidor.cerrarconexiontrans();
                //    __mesajeerror = servidor.getMensaje();
                //    Mensaje.Text = __mesajeerror;
                //    txtTemplate.Text = "";
                //    fpicture.Image = null;
                //    Txt_Nombre.Text = "";
                //    MessageBox.Show(__mesajeerror, "ZK4500", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //    //Hide();
                //}
                //else
                //{
                //    servidor.cancelarconexiontrans();
                //    Mensaje.Text = __mesajeerror;
                //    __mesajeerror = servidor.getMensaje();
                //    MessageBox.Show(__mesajeerror, "ZK4500", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                //}
            }
            else
            {
                __mesajeerror = servidor.getMensageError();
                Mensaje.Text = __mesajeerror;
                servidor.cerrarconexiontrans();
                MessageBox.Show(__mesajeerror, "ZK4500", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        
    }
    
}
