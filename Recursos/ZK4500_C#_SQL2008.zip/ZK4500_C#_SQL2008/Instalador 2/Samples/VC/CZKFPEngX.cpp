// CZKFPEngX.cpp  : Definition of ActiveX Control wrapper class(es) created by Microsoft Visual C++


#include "stdafx.h"
#include "CZKFPEngX.h"

/////////////////////////////////////////////////////////////////////////////
// CZKFPEngX

IMPLEMENT_DYNCREATE(CZKFPEngX, CWnd)

// CZKFPEngX properties

// CZKFPEngX operations
